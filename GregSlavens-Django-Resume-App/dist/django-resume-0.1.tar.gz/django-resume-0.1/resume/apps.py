from django.apps import AppConfig


class ResumeConfig(AppConfig):
    name = 'resume'
